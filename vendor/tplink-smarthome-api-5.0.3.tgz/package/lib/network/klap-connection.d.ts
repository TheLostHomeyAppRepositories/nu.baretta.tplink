import type Client from '../client';
import { type CredentialOptions } from '../credentials';
import type { Logger } from '../logger';
import type { ConnectionSendOptions, DeviceConnection } from './connection';
/**
 * @hidden
 */
export default class KlapConnection implements DeviceConnection {
    host: string;
    port: number;
    readonly log: Logger;
    readonly client: Client;
    private readonly queue;
    private readonly credentials?;
    private readonly credentialsHash?;
    private session?;
    private sessionCookie?;
    private sessionExpiresAt;
    constructor(host: string, port: number, log: Logger, client: Client, credentialOptions?: CredentialOptions);
    private get description();
    private resetSession;
    private isSessionExpired;
    private static authHashV1;
    private static authHashV2;
    private buildAuthCandidates;
    private static handshake1SeedAuthHash;
    private static handshake2SeedAuthHash;
    private selectAuthCandidate;
    private ensureSession;
    private sendEncryptedRequest;
    private isHttpsRequest;
    private post;
    send(payload: string, port: number, host: string, options: ConnectionSendOptions): Promise<string>;
    close(): void;
}
//# sourceMappingURL=klap-connection.d.ts.map