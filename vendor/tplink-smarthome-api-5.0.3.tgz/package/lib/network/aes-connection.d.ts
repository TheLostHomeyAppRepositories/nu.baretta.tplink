import type Client from '../client';
import { type CredentialOptions } from '../credentials';
import type { Logger } from '../logger';
import type { ConnectionSendOptions, DeviceConnection } from './connection';
/**
 * @hidden
 */
export default class AesConnection implements DeviceConnection {
    host: string;
    port: number;
    readonly log: Logger;
    readonly client: Client;
    private readonly queue;
    private readonly credentials?;
    private readonly credentialsHash?;
    private session?;
    private sessionCookie?;
    private sessionExpiresAt;
    private token?;
    constructor(host: string, port: number, log: Logger, client: Client, credentialOptions?: CredentialOptions);
    private get description();
    private resetSession;
    private isSessionExpired;
    private static hashLoginCredentials;
    private static parseCredentialsHash;
    private buildLoginCandidates;
    private static extractErrorCode;
    private static extractStatusCode;
    private assertResponseSuccess;
    private performHandshake;
    private tryLogin;
    private performLogin;
    private performLoginForCandidate;
    private ensureSession;
    private sendSecurePassthrough;
    private isHttpsRequest;
    private post;
    send(payload: string, port: number, host: string, options: ConnectionSendOptions): Promise<string>;
    private sendWithRetry;
    close(): void;
}
//# sourceMappingURL=aes-connection.d.ts.map