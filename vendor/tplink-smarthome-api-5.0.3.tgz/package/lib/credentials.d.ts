export interface Credentials {
    username: string;
    password: string;
}
export interface CredentialOptions {
    credentials?: Credentials;
    credentialsHash?: string;
}
export declare function normalizeCredentialOptions(options: CredentialOptions | undefined, context?: string): CredentialOptions;
export declare function mergeCredentialOptions(clientOptions: CredentialOptions | undefined, deviceOptions: CredentialOptions | undefined, context?: string): CredentialOptions;
export declare function redactCredentialOptions<T>(options: T): T;
//# sourceMappingURL=credentials.d.ts.map