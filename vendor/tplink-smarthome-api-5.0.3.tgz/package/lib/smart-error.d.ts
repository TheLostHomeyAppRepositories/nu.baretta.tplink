/**
 * Represents an error result received from a TP-Link SMART response.
 *
 * Where response `error_code` != `0`.
 */
export default class SmartError extends Error {
    readonly errorCode: number;
    readonly method: string;
    readonly response: string;
    readonly request: string;
    /**
     * Set by `Error.captureStackTrace`
     */
    readonly stack = "";
    constructor(message: string, errorCode: number, method: string, response: string, request: string);
}
//# sourceMappingURL=smart-error.d.ts.map