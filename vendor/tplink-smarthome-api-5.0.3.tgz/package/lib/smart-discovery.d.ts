/// <reference types="node" />
export declare const SMART_DISCOVERY_PORT = 20002;
export declare const SMART_DISCOVERY_ALT_PORT = 20004;
export declare const SMART_DISCOVERY_PORTS: readonly [20002, 20004];
type SmartTransport = 'klap' | 'aes';
type SmartDiscoveryHeader = {
    version: number;
    messageType: number;
    opcode: number;
    messageLength: number;
    flags: number;
    deviceSerial: number;
};
export type SmartDiscoveryPacket = SmartDiscoveryHeader & {
    payload: Record<string, unknown>;
};
export type NormalizedSmartSysInfo = Record<string, unknown> & {
    alias: string;
    name: string;
    deviceId: string;
    model: string;
    sw_ver: string;
    hw_ver: string;
    type: string;
    mac: string;
    device_on: boolean;
    relay_state: 0 | 1;
    mgt_encrypt_schm: Record<string, unknown>;
};
/**
 * Calculates the IEEE CRC-32 used by the TDP v2 discovery header.
 */
export declare function calculateTdpCrc32(data: Buffer): number;
/**
 * Creates the TP-Link TDP v2 probe used by current python-kasa discovery.
 *
 * The public key is deliberately cached for the process, matching python-kasa;
 * every packet still has a new serial and checksum.
 */
export declare function createSmartDiscoveryProbe(): Buffer;
/**
 * Parses the unencrypted TDP v2 outer payload. Inner encrypt_info data is not
 * decrypted here because routing only requires the outer discovery metadata.
 */
export declare function parseSmartDiscoveryPacket(message: Buffer): SmartDiscoveryPacket;
/**
 * Converts SMART get_device_info or TDP discovery metadata into the legacy
 * Sysinfo shape expected by the existing Plug implementation.
 */
export declare function normalizeSmartSysInfo(source: Record<string, unknown>, options?: {
    transport?: SmartTransport;
    port?: number;
}): NormalizedSmartSysInfo;
export {};
//# sourceMappingURL=smart-discovery.d.ts.map