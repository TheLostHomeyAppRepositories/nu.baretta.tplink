import type { SendOptions } from '../client';
import type Plug from './index';
/**
 * SMART fan control exposed by devices/channels with `fan_control`.
 */
export default class Fan {
    readonly device: Plug;
    readonly childId: string | undefined;
    constructor(device: Plug, childId?: string | undefined);
    /**
     * Cached fan speed level from sysInfo/child sysInfo.
     */
    get speedLevel(): number | undefined;
    /**
     * Cached fan sleep mode from sysInfo/child sysInfo.
     */
    get sleepModeOn(): boolean | undefined;
    private ensureSupported;
    /**
     * Requests SMART `get_device_info` for current scope.
     */
    getDeviceInfo(sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Sets fan speed using SMART `set_device_info`.
     * `0` turns the target off.
     */
    setFanSpeedLevel(level: number, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Sets fan sleep mode using SMART `set_device_info`.
     */
    setSleepMode(on: boolean, sendOptions?: SendOptions): Promise<unknown>;
}
//# sourceMappingURL=fan.d.ts.map