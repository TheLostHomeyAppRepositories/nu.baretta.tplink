import type { SendOptions } from '../client';
import type Plug from './index';
type TransitionState = {
    enable?: boolean;
    duration?: number;
    max_duration?: number;
};
export type LightTransitionInfo = {
    enable?: boolean;
    duration?: number;
    on_state?: TransitionState;
    off_state?: TransitionState;
} & Record<string, unknown>;
/**
 * SMART gradual on/off transitions (`on_off_gradually`).
 */
export default class LightTransition {
    readonly device: Plug;
    readonly childId: string | undefined;
    constructor(device: Plug, childId?: string | undefined);
    private ensureSupported;
    /**
     * Requests SMART `get_on_off_gradually_info`.
     */
    getInfo(sendOptions?: SendOptions): Promise<LightTransitionInfo>;
    /**
     * Sends SMART `set_on_off_gradually_info`.
     */
    setInfo(params: Record<string, unknown>, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Enables/disables gradual transitions.
     */
    setEnabled(enable: boolean, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Sets gradual turn-on duration (seconds) for devices exposing `on_state`.
     */
    setTurnOnTransition(seconds: number, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Sets gradual turn-off duration (seconds) for devices exposing `off_state`.
     */
    setTurnOffTransition(seconds: number, sendOptions?: SendOptions): Promise<unknown>;
    private setStateTransition;
}
export {};
//# sourceMappingURL=light-transition.d.ts.map