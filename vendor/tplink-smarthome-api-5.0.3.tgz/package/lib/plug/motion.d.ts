import type { SendOptions } from '../client';
import type Plug from './index';
declare const MOTION_RANGE_NAMES: readonly ["Far", "Mid", "Near", "Custom"];
export type MotionRangeName = (typeof MOTION_RANGE_NAMES)[number];
export type MotionConfigResponse = {
    array: number[];
    cold_time: number;
    enable: boolean | number;
    err_code: number;
    max_adc: number;
    min_adc: number;
    trigger_index: number;
    version?: string;
};
export type MotionAdcValueResponse = {
    err_code: number;
    value: number;
};
export type MotionState = {
    adcMax: number;
    adcMid: number;
    adcMin: number;
    adcValue: number;
    enabled: boolean;
    inactivityTimeout: number;
    pirPercent: number;
    pirTriggered: boolean;
    pirValue: number;
    rangeIndex: number;
    rangeName?: MotionRangeName;
    threshold: number;
};
/**
 * Legacy PIR motion module found on wall switches such as KS200M.
 */
export default class Motion {
    #private;
    readonly device: Plug;
    readonly apiModuleName: string;
    readonly childId: string | undefined;
    constructor(device: Plug, apiModuleName: string, childId?: string | undefined);
    private assertLegacyOnlyMethod;
    private static normalizeRange;
    private getRangeThreshold;
    private getAdcMid;
    private getStateFromCache;
    get config(): MotionConfigResponse | undefined;
    get state(): MotionState | undefined;
    getConfig(sendOptions?: SendOptions): Promise<MotionConfigResponse>;
    getAdcValue(sendOptions?: SendOptions): Promise<number>;
    getInfo(sendOptions?: SendOptions): Promise<MotionState | undefined>;
    setEnabled(value: boolean, sendOptions?: SendOptions): Promise<unknown>;
    setRange(range: MotionRangeName | number, sendOptions?: SendOptions): Promise<unknown>;
    setThreshold(value: number, sendOptions?: SendOptions): Promise<unknown>;
    setInactivityTimeout(timeout: number, sendOptions?: SendOptions): Promise<unknown>;
}
export {};
//# sourceMappingURL=motion.d.ts.map