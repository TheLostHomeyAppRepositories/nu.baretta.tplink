import type { SendOptions } from '../client';
import type Plug from './index';
export type AmbientLightPreset = {
    adc: number;
    name: string;
    value: number;
};
export type AmbientLightDeviceConfig = {
    dark_index?: number;
    enable?: boolean | number;
    hw_id?: number;
    level_array?: AmbientLightPreset[];
    max_adc?: number;
    min_adc?: number;
};
export type AmbientLightConfigResponse = {
    devs: AmbientLightDeviceConfig[];
    err_code: number;
    ver?: string;
};
/**
 * Legacy ambient light (LAS) module found on PIR wall switches such as KS200M.
 */
export default class AmbientLight {
    #private;
    readonly device: Plug;
    readonly apiModuleName: string;
    readonly childId: string | undefined;
    constructor(device: Plug, apiModuleName: string, childId?: string | undefined);
    private assertLegacyOnlyMethod;
    private applyConfig;
    get config(): AmbientLightDeviceConfig | undefined;
    get presets(): AmbientLightPreset[] | undefined;
    get enabled(): boolean | undefined;
    get brightness(): number | undefined;
    getConfig(sendOptions?: SendOptions): Promise<AmbientLightConfigResponse>;
    getCurrentBrightness(sendOptions?: SendOptions): Promise<number>;
    getInfo(sendOptions?: SendOptions): Promise<{
        config: AmbientLightDeviceConfig | undefined;
        brightness: number | undefined;
    }>;
    setEnabled(value: boolean, sendOptions?: SendOptions): Promise<unknown>;
    setBrightnessLimit(value: number, sendOptions?: SendOptions): Promise<unknown>;
}
//# sourceMappingURL=ambient-light.d.ts.map