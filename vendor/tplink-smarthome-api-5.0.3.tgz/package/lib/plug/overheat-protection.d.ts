import type { SendOptions } from '../client';
import type Plug from './index';
/**
 * SMART overheat status accessor.
 */
export default class OverheatProtection {
    readonly device: Plug;
    readonly childId: string | undefined;
    constructor(device: Plug, childId?: string | undefined);
    private ensureSupported;
    /**
     * Cached overheat status from sysInfo/child sysInfo.
     */
    get overheated(): boolean | undefined;
    /**
     * Refreshes SMART device info and returns current overheat status.
     */
    getOverheated(sendOptions?: SendOptions): Promise<boolean | undefined>;
}
//# sourceMappingURL=overheat-protection.d.ts.map