import type { SendOptions } from '../client';
import type Plug from './index';
export type SmartPresetRules = {
    brightness?: number[];
    states?: Record<string, unknown>[];
} & Record<string, unknown>;
/**
 * SMART light preset module exposed by devices/channels with `preset`.
 */
export default class LightPreset {
    readonly device: Plug;
    readonly childId: string | undefined;
    constructor(device: Plug, childId?: string | undefined);
    private ensureSupported;
    /**
     * Requests SMART `get_preset_rules`.
     */
    getPresetRules(sendOptions?: SendOptions): Promise<SmartPresetRules>;
    /**
     * Sends SMART `set_preset_rules`.
     */
    setPresetRules(rules: Record<string, unknown>, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Sends SMART `edit_preset_rules`.
     */
    editPresetRule(index: number, state: Record<string, unknown>, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Applies a preset by index using the brightness preset list.
     */
    setPreset(index: number, sendOptions?: SendOptions): Promise<unknown>;
}
//# sourceMappingURL=light-preset.d.ts.map