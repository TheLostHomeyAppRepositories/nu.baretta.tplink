import type { SendOptions } from '../client';
import type Plug from './index';
export type SmartLedInfo = {
    led_rule?: string;
    led_status?: boolean;
} & Record<string, unknown>;
/**
 * SMART LED module (`get_led_info` / `set_led_info`).
 */
export default class SmartLed {
    readonly device: Plug;
    readonly childId: string | undefined;
    constructor(device: Plug, childId?: string | undefined);
    private ensureSupported;
    /**
     * Requests SMART `get_led_info`.
     */
    getInfo(sendOptions?: SendOptions): Promise<SmartLedInfo>;
    /**
     * Returns LED state from SMART LED info.
     */
    getLedState(sendOptions?: SendOptions): Promise<boolean>;
    /**
     * Sets SMART LED state by updating `led_rule`.
     */
    setLedState(value: boolean, sendOptions?: SendOptions): Promise<true>;
}
//# sourceMappingURL=smart-led.d.ts.map