import type { SendOptions } from '../client';
import type Plug from './index';
export interface DimmerTransitionInput {
    /**
     * 0-100
     */
    brightness?: number;
    /**
     * "gentle_on_off", etc.
     */
    mode?: string;
    /**
     * duration in seconds
     */
    duration?: number;
}
export interface DimmerActionInput {
    mode?: string;
    index?: number;
}
/**
 * Dimmer
 *
 * TP-Link models: HS220 and child-dimmer channels exposed on some multi-channel switches.
 */
export default class Dimmer {
    #private;
    readonly device: Plug;
    readonly apiModuleName: string;
    readonly childId: string | undefined;
    /**
     * @internal
     */
    lastState: {
        brightness: number;
    };
    constructor(device: Plug, apiModuleName: string, childId?: string | undefined);
    /**
     * Cached value of `sysinfo.brightness`.
     */
    get brightness(): number;
    /**
     * @internal
     */
    setBrightnessValue(brightness: number): void;
    private ensureSmartDimmerSupported;
    private assertLegacyOnlyMethod;
    /**
     * Sets Plug to the specified `brightness`.
     *
     * Sends `dimmer.set_brightness` command. Supports childId when configured on `Plug`.
     * For SMART dimmers, zero turns the device off without changing its saved brightness.
     * @param   brightness - 0-100
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setBrightness(brightness: number, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Get Plug/Dimmer default behavior configuration.
     *
     * Requests `dimmer.get_default_behavior`. Supports childId when configured on `Plug`.
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    getDefaultBehavior(sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Get Plug/Dimmer parameters configuration.
     *
     * Requests `dimmer.get_dimmer_parameters`. Supports childId when configured on `Plug`.
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    getDimmerParameters(sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Transitions Plug to the specified `brightness`.
     *
     * Sends `dimmer.set_dimmer_transition` command. Supports childId when configured on `Plug`.
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setDimmerTransition(dimmerTransition: DimmerTransitionInput, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Set Plug/Dimmer `default_behavior` configuration for `double_click`.
     *
     * Sends `dimmer.set_double_click_action`. Supports childId when configured on `Plug`.
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setDoubleClickAction({ mode, index }: DimmerActionInput, sendOptions?: SendOptions): Promise<unknown>;
    private setAction;
    /**
     * Set Plug `dimmer_parameters` for `fadeOffTime`.
     *
     * Sends `dimmer.set_fade_off_time`. Supports childId when configured on `Plug`.
     * @param   fadeTime - duration in ms
     * @param   sendOptions
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setFadeOffTime(fadeTime: number, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Set Plug `dimmer_parameters` for `fadeOnTime`.
     *
     * Sends `dimmer.set_fade_on_time`. Supports childId when configured on `Plug`.
     * @param   fadeTime - duration in ms
     * @param   sendOptions
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setFadeOnTime(fadeTime: number, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Set Plug `dimmer_parameters` for `gentleOffTime`.
     *
     * Sends `dimmer.set_gentle_off_time`. Supports childId when configured on `Plug`.
     * @param   duration - duration in ms
     * @param   sendOptions
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setGentleOffTime(duration: number, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Set Plug `dimmer_parameters` for `gentleOnTime`.
     *
     * Sends `dimmer.set_gentle_on_time`. Supports childId when configured on `Plug`.
     * @param   duration - duration in ms
     * @param   sendOptions
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setGentleOnTime(duration: number, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Set Plug/Dimmer `default_behavior` configuration for `long_press`.
     *
     * Sends `dimmer.set_long_press_action`. Supports childId when configured on `Plug`.
     * @param   options
     * @param   options.mode
     * @param   options.index
     * @param   sendOptions
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setLongPressAction({ mode, index }: DimmerActionInput, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * Sets Plug to the specified on/off state.
     *
     * Sends `dimmer.set_switch_state` command. Supports childId when configured on `Plug`.
     * @param  {Boolean}     state  true=on, false=off
     * @param  {SendOptions} [sendOptions]
     * @returns parsed JSON response
     * @throws {@link ResponseError}
     */
    setSwitchState(state: boolean | 0 | 1, sendOptions?: SendOptions): Promise<unknown>;
    /**
     * @internal
     */
    emitEvents(): void;
}
//# sourceMappingURL=dimmer.d.ts.map